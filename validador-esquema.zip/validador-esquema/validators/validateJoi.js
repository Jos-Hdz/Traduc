export function validateJoi(joiSchema, data) {
    const { error } = joiSchema.validate(data);
    if (error) {
      console.error("Errores de validación con Joi:", error.details);
    } else {
      console.log("Validación con Joi exitosa.");
    }
  }
  