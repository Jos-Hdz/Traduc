// validateAjv.js
import { generateAjvSchema } from '../generators/generateAjv.js';

export function validateAjv(schema, data) {
  const valid = schema(data);
  if (valid) {
    console.log('Validación con AJV exitosa.');
  } else {
    console.log('Errores de validación con AJV:', schema.errors);
  }
}
