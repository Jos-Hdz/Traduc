export function validateZod(zodSchema, data) {
    try {
      zodSchema.parse(data);
      console.log("Validación con Zod exitosa.");
    } catch (error) {
      console.error("Errores de validación con Zod:", error.errors);
    }
  }
  