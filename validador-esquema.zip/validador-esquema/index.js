import { generateAjvSchema } from './generators/generateAjv.js';
import { generateZodSchema } from './generators/generateZod.js';
import { generateJoiSchema } from './generators/generateJoi.js';
import { validateAjv } from './validators/validateAjv.js';
import { validateZod } from './validators/validateZod.js';
import { validateJoi } from './validators/validateJoi.js';

// Ejemplo de esquema JSON para validar
const ejemploSchema = {
  type: "object",
  properties: {
    nombre: { type: "string" },
    edad: { type: "integer" }
  },
  required: ["nombre", "edad"],
  additionalProperties: false
};

// Generación y validación con AJV
console.log("Validando con AJV...");
const ajvSchema = generateAjvSchema(ejemploSchema);
validateAjv(ajvSchema, { nombre: "Juan", edad: 30 });

// Generación y validación con Zod
console.log("Validando con Zod...");
const zodSchema = generateZodSchema(ejemploSchema);
validateZod(zodSchema, { nombre: "Juan", edad: 30 });

// Generación y validación con Joi
console.log("Validando con Joi...");
const joiSchema = generateJoiSchema(ejemploSchema);
validateJoi(joiSchema, { nombre: "Juan", edad: 30 });
