import Ajv from 'ajv';

export function generateAjvSchema(jsonSchema) {
  const ajv = new Ajv();
  return ajv.compile(jsonSchema);
}
