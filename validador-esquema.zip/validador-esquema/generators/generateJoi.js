import Joi from 'joi';

export function generateJoiSchema(jsonSchema) {
  return Joi.object({
    nombre: Joi.string().required(),
    edad: Joi.number().integer().required(),
  });
}
