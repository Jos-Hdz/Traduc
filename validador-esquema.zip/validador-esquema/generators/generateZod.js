import { z } from 'zod';

export function generateZodSchema(jsonSchema) {
  // Convertimos el esquema JSON a Zod
  return z.object({
    nombre: z.string(),
    edad: z.number().int(),
  });
}
