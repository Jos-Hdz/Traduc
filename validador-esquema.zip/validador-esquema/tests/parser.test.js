import { parseJsonSchema } from '../parser.js';

test('Debe parsear el esquema JSON correctamente', () => {
  const schema = {
    type: "object",
    properties: {
      nombre: { type: "string" },
      edad: { type: "integer" }
    },
    required: ["nombre", "edad"]
  };
  const result = parseJsonSchema(schema);
  expect(result).toEqual(schema);
});
