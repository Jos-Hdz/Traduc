import { generateAjvSchema } from '../generators/generateAjv.js';
import { validateAjv } from '../validators/validateAjv.js';

test('Validación exitosa con AJV', () => {
  const schema = {
    type: "object",
    properties: {
      nombre: { type: "string" },
      edad: { type: "integer" }
    },
    required: ["nombre", "edad"],
    additionalProperties: false
  };

  const ajvSchema = generateAjvSchema(schema);
  const data = { nombre: "Juan", edad: 30 };
  
  validateAjv(ajvSchema, data);  // Debe imprimir "Validación con AJV exitosa."
});

test('Validación fallida con AJV', () => {
  const schema = {
    type: "object",
    properties: {
      nombre: { type: "string" },
      edad: { type: "integer" }
    },
    required: ["nombre", "edad"],
    additionalProperties: false
  };

  const ajvSchema = generateAjvSchema(schema);
  const data = { nombre: "Juan" };  // Falta el campo "edad"
  
  validateAjv(ajvSchema, data);  // Debe imprimir los errores de validación
});
