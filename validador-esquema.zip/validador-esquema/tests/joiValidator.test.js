import { generateJoiSchema } from '../generators/generateJoi.js';
import { validateJoi } from '../validators/validateJoi.js';

describe('Pruebas de validación con Joi', () => {
  test('Validación exitosa con Joi', () => {
    const schema = {
      type: 'object',
      properties: {
        nombre: { type: 'string' },
        edad: { type: 'integer' },
      },
      required: ['nombre', 'edad'],
    };

    const joiSchema = generateJoiSchema(schema); // Genera el esquema Joi
    const data = { nombre: 'Juan', edad: 30 };  // Datos a validar

    // Llamada a la función que valida con Joi
    validateJoi(joiSchema, data);

    // El resultado esperado es que se imprima "Validación con Joi exitosa."
  });

  test('Validación fallida con Joi', () => {
    const schema = {
      type: 'object',
      properties: {
        nombre: { type: 'string' },
        edad: { type: 'integer' },
      },
      required: ['nombre', 'edad'],
    };

    const joiSchema = generateJoiSchema(schema); // Genera el esquema Joi
    const data = { nombre: 'Juan' };  // Falta el campo "edad"

    // Llamada a la función que valida con Joi
    validateJoi(joiSchema, data);

    // El resultado esperado es que se impriman los errores de validación
  });
});
