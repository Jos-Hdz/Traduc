import { generateZodSchema } from '../generators/generateZod.js';
import { validateZod } from '../validators/validateZod.js';

test('Validación exitosa con Zod', () => {
  const schema = {
    type: "object",
    properties: {
      nombre: { type: "string" },
      edad: { type: "integer" }
    },
    required: ["nombre", "edad"]
  };

  const zodSchema = generateZodSchema(schema);
  const data = { nombre: "Juan", edad: 30 };
  
  validateZod(zodSchema, data);  // Debe imprimir "Validación con Zod exitosa."
});

test('Validación fallida con Zod', () => {
  const schema = {
    type: "object",
    properties: {
      nombre: { type: "string" },
      edad: { type: "integer" }
    },
    required: ["nombre", "edad"]
  };

  const zodSchema = generateZodSchema(schema);
  const data = { nombre: "Juan" };  // Falta el campo "edad"
  
  validateZod(zodSchema, data);  // Debe imprimir los errores de validación
});
